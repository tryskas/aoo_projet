/**
 * 
 */
/**
 * 
 */
module Csg {
	requires java.desktop;
}